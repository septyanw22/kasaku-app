/**
 * KASAKU v5 — Google Apps Script Cloud Sync Backend
 * Tempel ke script.google.com -> Deploy -> New Deployment -> Web App
 * Execute as: Me | Who has access: Anyone
 */

const SHEET_STATE = 'KASAKU_JSON_STORE';
const SHEET_TX = 'Transaksi_Log';

function getOrCreateSheet(ss, name) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
  }
  return sheet;
}

function doGet() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = getOrCreateSheet(ss, SHEET_STATE);
    const raw = sheet.getRange('A1').getValue();
    if (!raw) {
      return ContentService.createTextOutput(
        JSON.stringify({ status: 'success', data: null })
      ).setMimeType(ContentService.MimeType.JSON);
    }
    return ContentService.createTextOutput(
      JSON.stringify({ status: 'success', data: JSON.parse(raw) })
    ).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(
      JSON.stringify({ status: 'error', message: err.toString() })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const payload = JSON.parse(e.postData.contents);
    if (payload.action === 'syncAll' && payload.data) {
      const ss = SpreadsheetApp.getActiveSpreadsheet();
      const storeSheet = getOrCreateSheet(ss, SHEET_STATE);
      const syncedAt = new Date().toISOString();

      storeSheet.getRange('A1').setValue(JSON.stringify(payload.data));
      storeSheet.getRange('B1').setValue('Last Synced: ' + syncedAt);

      // Mirror transactions to readable Google Sheet tab
      const txSheet = getOrCreateSheet(ss, SHEET_TX);
      txSheet.clear();
      const headers = ['ID', 'Tanggal', 'Tipe', 'Kategori', 'Dompet Asal', 'Dompet Tujuan', 'Nominal', 'Biaya Admin', 'Catatan', 'Updated At'];
      const rows = (payload.data.transactions || []).map(t => [
        t.id || '',
        t.date || '',
        t.type || '',
        t.category || '',
        t.wallet || '',
        t.toWallet || '',
        Number(t.amount) || 0,
        Number(t.fee) || 0,
        t.note || '',
        t.updatedAt || ''
      ]);
      txSheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      if (rows.length > 0) {
        txSheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
      }

      return ContentService.createTextOutput(
        JSON.stringify({ status: 'success', syncedAt: syncedAt })
      ).setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService.createTextOutput(
      JSON.stringify({ status: 'error', message: 'Unknown action' })
    ).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(
      JSON.stringify({ status: 'error', message: err.toString() })
    ).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}
